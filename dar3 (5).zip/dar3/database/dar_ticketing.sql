-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 20, 2026 at 11:10 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dar_ticketing`
--

-- --------------------------------------------------------

--
-- Table structure for table `queue_counters`
--

CREATE TABLE `queue_counters` (
  `queue_date` date NOT NULL,
  `ticket_type` char(1) NOT NULL,
  `last_no` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `queue_counters`
--

INSERT INTO `queue_counters` (`queue_date`, `ticket_type`, `last_no`) VALUES
('2026-10-15', 'T', 2),
('2026-10-20', 'T', 3);

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` tinyint(3) UNSIGNED NOT NULL,
  `name` varchar(120) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `name`, `active`) VALUES
(1, 'Kopya ng Land Title (CLOA/EP)', 1),
(2, 'Certified True Copy ng Dokumento', 1),
(3, 'Land Ownership Inquiry', 1),
(4, 'Certification (DAR Clearance)', 1),
(5, 'Reklamo / Agrarian Case', 1);

-- --------------------------------------------------------

--
-- Table structure for table `service_steps`
--

CREATE TABLE `service_steps` (
  `service_id` tinyint(3) UNSIGNED NOT NULL,
  `step_no` tinyint(3) UNSIGNED NOT NULL,
  `unit_id` tinyint(3) UNSIGNED NOT NULL,
  `label` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `service_steps`
--

INSERT INTO `service_steps` (`service_id`, `step_no`, `unit_id`, `label`) VALUES
(1, 1, 1, 'Pagtanggap at pag-verify ng dokumento'),
(1, 2, 2, 'Paghahanap ng titulo sa records'),
(1, 3, 3, 'Pagsusuri at certification'),
(1, 4, 4, 'Pagbabayad ng fees'),
(1, 5, 5, 'Pagpapalabas ng kopya'),
(2, 1, 1, 'Pagtanggap at pag-verify ng dokumento'),
(2, 2, 2, 'Paghahanap at pagkopya ng dokumento'),
(2, 3, 4, 'Pagbabayad ng fees'),
(2, 4, 5, 'Pagpapalabas ng kopya'),
(3, 1, 1, 'Pagtanggap ng inquiry'),
(3, 2, 2, 'Pag-check sa records'),
(3, 3, 5, 'Pagbibigay ng sagot'),
(4, 1, 1, 'Pagtanggap at pag-verify ng dokumento'),
(4, 2, 3, 'Pagsusuri at pag-isyu ng certification'),
(4, 3, 4, 'Pagbabayad ng fees'),
(4, 4, 5, 'Pagpapalabas ng certification'),
(5, 1, 1, 'Pagtanggap ng reklamo'),
(5, 2, 3, 'Pagsusuri ng reklamo');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(40) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `full_name` varchar(120) NOT NULL,
  `surname` varchar(60) DEFAULT NULL,
  `first_name` varchar(60) DEFAULT NULL,
  `middle_name` varchar(60) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `unit_id` tinyint(3) UNSIGNED NOT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT 0,
  `must_change_pw` tinyint(1) NOT NULL DEFAULT 0,
  `active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`id`, `username`, `password_hash`, `full_name`, `surname`, `first_name`, `middle_name`, `birthday`, `unit_id`, `is_admin`, `must_change_pw`, `active`) VALUES
(3, 'admin', '$2y$10$uZrA0xqXD2Gt5UKJYFHToeCzN1G5tnTswESFAJMWKTLUDJarj/Dv.', 'DAR Admin', NULL, NULL, NULL, NULL, 1, 1, 0, 1),
(4, 'front1', '$2y$10$u6z1OQrukvgVwQOuyp8ZqOIKNia5YGSMox3/fQzX5jks7R5T9WNhC', 'Maria Front', NULL, NULL, NULL, NULL, 1, 0, 0, 1),
(5, 'records1', '$2y$10$DOwE66HUkNCojuLak.pM8.MI.jo5c9p8aY5pPCKxZ1sBA4VzrNGWe', 'Juan Records', NULL, NULL, NULL, NULL, 2, 0, 0, 1),
(6, 'legal1', '$2y$10$6uGERAa8zhSEVbtBFIQ5A.E9i2of9OUJ0/UvaQFCL7ZhjuOFcA44W', 'Ana Legal', NULL, NULL, NULL, NULL, 3, 0, 0, 1),
(7, 'cashier1', '$2y$10$f96wmB4I4vLkrptvXZIDoOEwopV29oLA757T10QADF5jfpA2to2Um', 'Pedro Cashier', NULL, NULL, NULL, NULL, 4, 0, 0, 1),
(8, 'release1', '$2y$10$enWQ5EwH3WeidZyc9w0VJe3XqhYNORX2TI5N709G3v/FLoCQg9Z0S', 'Liza Release', NULL, NULL, NULL, NULL, 5, 0, 0, 1),
(9, 'admin2', '7488e331b8b64e5794da3fa4eb10ad5d', 'ADMIN 2', NULL, NULL, NULL, NULL, 1, 1, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `staff_calls`
--

CREATE TABLE `staff_calls` (
  `id` int(10) UNSIGNED NOT NULL,
  `staff_id` int(10) UNSIGNED NOT NULL,
  `called_by` int(10) UNSIGNED NOT NULL,
  `destination` varchar(80) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `staff_calls`
--

INSERT INTO `staff_calls` (`id`, `staff_id`, `called_by`, `destination`, `created_at`) VALUES
(1, 9, 4, 'Front Desk (Receiving)', '2026-10-20 11:20:22'),
(2, 9, 3, 'Front Desk (Receiving)', '2026-10-20 13:33:27'),
(3, 9, 3, 'Front Desk (Receiving)', '2026-10-20 13:33:46'),
(4, 9, 3, 'Front Desk (Receiving)', '2026-10-20 13:34:08'),
(5, 5, 3, 'Baba', '2026-10-20 13:34:57');

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE `tickets` (
  `id` int(10) UNSIGNED NOT NULL,
  `ref_no` char(15) NOT NULL,
  `queue_date` date NOT NULL,
  `queue_no` int(10) UNSIGNED NOT NULL,
  `ticket_type` char(1) NOT NULL,
  `full_name` varchar(120) NOT NULL,
  `contact_no` varchar(30) DEFAULT NULL,
  `service_id` tinyint(3) UNSIGNED NOT NULL,
  `appt_at` datetime DEFAULT NULL,
  `status` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tickets`
--

INSERT INTO `tickets` (`id`, `ref_no`, `queue_date`, `queue_no`, `ticket_type`, `full_name`, `contact_no`, `service_id`, `appt_at`, `status`, `created_at`, `updated_at`) VALUES
(1, 'DAR-261015-794B', '2026-10-15', 1, 'T', 'JC Espinase', '09123456789', 3, NULL, 1, '2026-10-15 07:59:12', '2026-10-15 07:59:38'),
(2, 'DAR-261015-LX8R', '2026-10-15', 2, 'T', 'Juan Totri', '09123456789', 5, NULL, 1, '2026-10-15 11:30:49', '2026-10-15 11:34:01'),
(3, 'DAR-261020-52CD', '2026-10-20', 1, 'T', 'Maria Makiling', '09123456789', 3, NULL, 1, '2026-10-20 07:42:34', '2026-10-20 09:38:53'),
(4, 'DAR-261020-PRJP', '2026-10-20', 2, 'T', 'ftftyr', '09123456789', 3, NULL, 1, '2026-10-20 07:55:28', '2026-10-20 09:34:08'),
(5, 'DAR-261020-MTBQ', '2026-10-20', 3, 'T', 'John Carlo Espinase', '09123456789', 1, NULL, 1, '2026-10-20 10:13:51', '2026-10-20 10:15:01');

-- --------------------------------------------------------

--
-- Table structure for table `ticket_events`
--

CREATE TABLE `ticket_events` (
  `id` int(10) UNSIGNED NOT NULL,
  `ticket_id` int(10) UNSIGNED NOT NULL,
  `step_no` tinyint(3) UNSIGNED DEFAULT NULL,
  `action` varchar(20) NOT NULL,
  `staff_id` int(10) UNSIGNED DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ticket_events`
--

INSERT INTO `ticket_events` (`id`, `ticket_id`, `step_no`, `action`, `staff_id`, `remarks`, `created_at`) VALUES
(1, 1, 1, 'checkin', 3, NULL, '2026-10-15 07:59:38'),
(2, 1, 1, 'start', 4, NULL, '2026-10-15 08:04:43'),
(3, 1, 1, 'done', 4, NULL, '2026-10-15 08:05:28'),
(4, 1, 2, 'start', 3, NULL, '2026-10-15 11:08:38'),
(5, 1, 2, 'done', 3, NULL, '2026-10-15 11:08:42'),
(6, 2, 1, 'checkin', 3, NULL, '2026-10-15 11:34:01'),
(7, 2, 1, 'start', 4, NULL, '2026-10-15 11:34:41'),
(8, 2, 1, 'done', 4, NULL, '2026-10-15 11:34:44'),
(9, 4, 1, 'checkin', 4, NULL, '2026-10-20 09:34:08'),
(10, 3, 1, 'checkin', 4, NULL, '2026-10-20 09:38:53'),
(11, 5, 1, 'checkin', 4, NULL, '2026-10-20 10:15:01'),
(12, 5, 1, 'start', 4, NULL, '2026-10-20 10:15:08'),
(13, 5, 1, 'done', 4, NULL, '2026-10-20 10:16:26');

-- --------------------------------------------------------

--
-- Table structure for table `ticket_steps`
--

CREATE TABLE `ticket_steps` (
  `ticket_id` int(10) UNSIGNED NOT NULL,
  `step_no` tinyint(3) UNSIGNED NOT NULL,
  `unit_id` tinyint(3) UNSIGNED NOT NULL,
  `label` varchar(120) NOT NULL,
  `state` enum('pending','waiting','processing','done') NOT NULL DEFAULT 'pending',
  `ready_at` datetime DEFAULT NULL,
  `started_at` datetime DEFAULT NULL,
  `finished_at` datetime DEFAULT NULL,
  `staff_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ticket_steps`
--

INSERT INTO `ticket_steps` (`ticket_id`, `step_no`, `unit_id`, `label`, `state`, `ready_at`, `started_at`, `finished_at`, `staff_id`) VALUES
(1, 1, 1, 'Pagtanggap ng inquiry', 'done', '2026-10-15 07:59:38', '2026-10-15 08:04:43', '2026-10-15 08:05:28', 4),
(1, 2, 2, 'Pag-check sa records', 'done', '2026-10-15 08:05:28', '2026-10-15 11:08:38', '2026-10-15 11:08:42', 3),
(1, 3, 5, 'Pagbibigay ng sagot', 'waiting', '2026-10-15 11:08:42', NULL, NULL, NULL),
(2, 1, 1, 'Pagtanggap ng reklamo', 'done', '2026-10-15 11:34:01', '2026-10-15 11:34:41', '2026-10-15 11:34:44', 4),
(2, 2, 3, 'Pagsusuri ng reklamo', 'waiting', '2026-10-15 11:34:44', NULL, NULL, NULL),
(3, 1, 1, 'Pagtanggap ng inquiry', 'waiting', '2026-10-20 09:38:53', NULL, NULL, NULL),
(3, 2, 2, 'Pag-check sa records', 'pending', NULL, NULL, NULL, NULL),
(3, 3, 5, 'Pagbibigay ng sagot', 'pending', NULL, NULL, NULL, NULL),
(4, 1, 1, 'Pagtanggap ng inquiry', 'waiting', '2026-10-20 09:34:08', NULL, NULL, NULL),
(4, 2, 2, 'Pag-check sa records', 'pending', NULL, NULL, NULL, NULL),
(4, 3, 5, 'Pagbibigay ng sagot', 'pending', NULL, NULL, NULL, NULL),
(5, 1, 1, 'Pagtanggap at pag-verify ng dokumento', 'done', '2026-10-20 10:15:01', '2026-10-20 10:15:08', '2026-10-20 10:16:26', 4),
(5, 2, 2, 'Paghahanap ng titulo sa records', 'waiting', '2026-10-20 10:16:26', NULL, NULL, NULL),
(5, 3, 3, 'Pagsusuri at certification', 'pending', NULL, NULL, NULL, NULL),
(5, 4, 4, 'Pagbabayad ng fees', 'pending', NULL, NULL, NULL, NULL),
(5, 5, 5, 'Pagpapalabas ng kopya', 'pending', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `units`
--

CREATE TABLE `units` (
  `id` tinyint(3) UNSIGNED NOT NULL,
  `code` varchar(12) NOT NULL,
  `name` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `units`
--

INSERT INTO `units` (`id`, `code`, `name`) VALUES
(1, 'FRONT', 'Front Desk (Receiving)'),
(2, 'RECORDS', 'Records Section'),
(3, 'LEGAL', 'Legal Division'),
(4, 'CASHIER', 'Cashier'),
(5, 'RELEASE', 'Releasing Section');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `queue_counters`
--
ALTER TABLE `queue_counters`
  ADD PRIMARY KEY (`queue_date`,`ticket_type`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service_steps`
--
ALTER TABLE `service_steps`
  ADD PRIMARY KEY (`service_id`,`step_no`),
  ADD KEY `unit_id` (`unit_id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `unit_id` (`unit_id`);

--
-- Indexes for table `staff_calls`
--
ALTER TABLE `staff_calls`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_created` (`created_at`),
  ADD KEY `idx_staff` (`staff_id`,`created_at`),
  ADD KEY `called_by` (`called_by`);

--
-- Indexes for table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `ref_no` (`ref_no`),
  ADD UNIQUE KEY `uq_queue` (`queue_date`,`ticket_type`,`queue_no`),
  ADD KEY `idx_board` (`queue_date`,`status`),
  ADD KEY `service_id` (`service_id`);

--
-- Indexes for table `ticket_events`
--
ALTER TABLE `ticket_events`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_ticket` (`ticket_id`);

--
-- Indexes for table `ticket_steps`
--
ALTER TABLE `ticket_steps`
  ADD PRIMARY KEY (`ticket_id`,`step_no`),
  ADD KEY `idx_unit_state` (`unit_id`,`state`),
  ADD KEY `staff_id` (`staff_id`);

--
-- Indexes for table `units`
--
ALTER TABLE `units`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `staff_calls`
--
ALTER TABLE `staff_calls`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tickets`
--
ALTER TABLE `tickets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `ticket_events`
--
ALTER TABLE `ticket_events`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `units`
--
ALTER TABLE `units`
  MODIFY `id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `service_steps`
--
ALTER TABLE `service_steps`
  ADD CONSTRAINT `service_steps_ibfk_1` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`),
  ADD CONSTRAINT `service_steps_ibfk_2` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`);

--
-- Constraints for table `staff`
--
ALTER TABLE `staff`
  ADD CONSTRAINT `staff_ibfk_1` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`);

--
-- Constraints for table `staff_calls`
--
ALTER TABLE `staff_calls`
  ADD CONSTRAINT `staff_calls_ibfk_1` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`id`),
  ADD CONSTRAINT `staff_calls_ibfk_2` FOREIGN KEY (`called_by`) REFERENCES `staff` (`id`);

--
-- Constraints for table `tickets`
--
ALTER TABLE `tickets`
  ADD CONSTRAINT `tickets_ibfk_1` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`);

--
-- Constraints for table `ticket_events`
--
ALTER TABLE `ticket_events`
  ADD CONSTRAINT `ticket_events_ibfk_1` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`);

--
-- Constraints for table `ticket_steps`
--
ALTER TABLE `ticket_steps`
  ADD CONSTRAINT `ticket_steps_ibfk_1` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`),
  ADD CONSTRAINT `ticket_steps_ibfk_2` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`),
  ADD CONSTRAINT `ticket_steps_ibfk_3` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
