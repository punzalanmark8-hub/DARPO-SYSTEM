/* Shared na code ng mga client page (walkin.html, appointment.html, status.html) */
(function(){
var D=window.DAR={};
function $(i){return document.getElementById(i)}
D.$=$;
D.esc=function(s){return String(s==null?'':s).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})};
D.api=function(action,data){
  var o={credentials:'same-origin'};
  if(data){o.method='POST';o.headers={'Content-Type':'application/json'};o.body=JSON.stringify(data)}
  return fetch('api.php?action='+action,o).then(function(r){
    return r.json().catch(function(){throw new Error('Hindi makakonekta sa server.')}).then(function(j){if(!r.ok)throw new Error(j.error||'May error.');return j})})};
D.ymd=function(d){var m=d.getMonth()+1,x=d.getDate();return d.getFullYear()+'-'+(m<10?'0':'')+m+'-'+(x<10?'0':'')+x};
D.time12=function(t){var h=+t.slice(0,2),m=t.slice(3,5);return (h%12||12)+':'+m+' '+(h<12?'AM':'PM')};
D.fmtWhen=function(w){ /* 'YYYY-MM-DD HH:MM' */
  var d=new Date(w.replace(' ','T'));if(isNaN(d))return w;
  return d.toLocaleDateString('en-PH',{weekday:'short',month:'short',day:'numeric',year:'numeric'})+', '+D.time12(w.slice(11,16))};
D.refOf=function(v){var m=String(v||'').toUpperCase().match(/DAR-\d{6}-[A-Z0-9]{4}/);return m?m[0]:''};
D.statusUrl=function(ref){return new URL('appointment.html?ref='+encodeURIComponent(ref),location.href).href};
/* mga huling ref sa device na ito */
D.saveRef=function(ref){try{var a=JSON.parse(localStorage.getItem('dar_refs')||'[]').filter(function(x){return x!==ref});a.unshift(ref);localStorage.setItem('dar_refs',JSON.stringify(a.slice(0,5)))}catch(e){}};
D.savedRefs=function(){try{return JSON.parse(localStorage.getItem('dar_refs')||'[]')}catch(e){return[]}};

/* ---------- Form ng ticket / appointment ---------- */
if($('gen')){
  var type=document.body.dataset.type||'T';
  var fe=$('fe');
  function showErr(m){fe.textContent=m;fe.classList.remove('hide')}
  D.api('services').then(function(r){$('sv').innerHTML=r.services.map(function(s){return '<option value="'+s.id+'">'+D.esc(s.name)+'</option>'}).join('')})
   .catch(function(e){showErr(e.message)});

  if(type=='A'){
    var d=new Date();d.setDate(d.getDate()+1);while(d.getDay()==0||d.getDay()==6)d.setDate(d.getDate()+1);
    $('dt').value=D.ymd(d);$('dt').min=D.ymd(new Date());
    var loadSlots=function(){
      var v=$('dt').value;if(!v)return;
      D.api('slots',{date:v}).then(function(r){
        fe.classList.add('hide');
        $('tm').innerHTML=r.slots.map(function(s){return '<option value="'+s.time+'"'+(s.left<1?' disabled':'')+'>'+D.time12(s.time)+(s.left<1?' — puno na':' — '+s.left+' bakante')+'</option>'}).join('');
        var f=r.slots.filter(function(s){return s.left>0})[0];
        if(f)$('tm').value=f.time;else showErr('Puno na ang lahat ng oras sa petsang ito. Pumili ng ibang araw.');
      }).catch(function(e){$('tm').innerHTML='';showErr(e.message)})};
    $('dt').onchange=loadSlots;loadSlots();
  }

  $('gen').onclick=function(){
    fe.classList.add('hide');$('gen').disabled=true;
    var body={type:type,name:$('nm').value,contact:$('ct').value,service_id:+$('sv').value};
    if(type=='A'){body.date=$('dt').value;body.time=$('tm').value}
    D.api('create',body).then(function(r){showTicket(r.ticket)}).catch(function(e){showErr(e.message)}).then(function(){$('gen').disabled=false})};

  function showTicket(t){
    D.saveRef(t.ref);
    $('formCard').classList.add('hide');$('tkCard').classList.remove('hide');
    $('tkType').textContent=t.type=='A'?'Appointment — '+D.fmtWhen(t.when):'Ticket (Walk-in)';
    $('tkQ').textContent=t.q;$('tkRef').textContent=t.ref;
    $('tkInfo').textContent=t.service+' • '+t.name+' • Unang pupuntahan: '+t.first_unit;
    var url=D.statusUrl(t.ref);if($('tkLink'))$('tkLink').href=url;
    var qr=$('qr');qr.innerHTML='';
    try{new QRCode(qr,{text:url,width:180,height:180})}catch(e){qr.textContent='[QR]'}
    window.scrollTo(0,0)}
  $('newTk').onclick=function(){$('tkCard').classList.add('hide');$('formCard').classList.remove('hide');$('nm').value='';$('ct').value='';if(type=='A')$('dt').onchange()};
}
})();