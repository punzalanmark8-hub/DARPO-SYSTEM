<?php
// CLI lang: php create_staff.php <username> "<Full Name>" <UNIT_CODE> <password> [--admin]
// Units: FRONT, RECORDS, LEGAL, CASHIER, RELEASE
if (PHP_SAPI !== 'cli') { http_response_code(403); exit; }
require __DIR__ . '/config.php';

$a = array_values(array_filter($argv, fn($x) => $x !== '--admin'));
$admin = in_array('--admin', $argv, true) ? 1 : 0;
if (count($a) < 5) {
    fwrite(STDERR, "Usage: php create_staff.php <username> \"<Full Name>\" <UNIT_CODE> <password> [--admin]\n");
    exit(1);
}
[, $user, $name, $unit, $pass] = $a;
if (strlen($pass) < 8) { fwrite(STDERR, "Password: at least 8 characters.\n"); exit(1); }

$u = db()->prepare('SELECT id FROM units WHERE code = ?');
$u->execute([strtoupper($unit)]);
$uid = $u->fetchColumn();
if (!$uid) { fwrite(STDERR, "Unknown unit code.\n"); exit(1); }

db()->prepare('INSERT INTO staff (username, password_hash, full_name, unit_id, is_admin) VALUES (?,?,?,?,?)
               ON DUPLICATE KEY UPDATE password_hash = VALUES(password_hash), full_name = VALUES(full_name),
               unit_id = VALUES(unit_id), is_admin = VALUES(is_admin)')
     ->execute([$user, password_hash($pass, PASSWORD_DEFAULT), $name, $uid, $admin]);
echo "OK: $user ($unit)" . ($admin ? ' [admin]' : '') . "\n";
