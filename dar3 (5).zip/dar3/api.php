<?php
declare(strict_types=1);
require __DIR__ . '/config.php';

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');

/** Kusang nag-a-update ng lumang database (idinadagdag ang mga bagong column/table). Hindi na kailangang i-run ang migration .sql nang mano-mano. */
function ensure_schema(): void {
    if (!empty($_SESSION['schema_ok'])) return;
    $pdo = db();
    $has = fn(string $col): bool => (bool)$pdo->query("SHOW COLUMNS FROM staff LIKE '$col'")->fetch();
    $add = ['surname'        => 'VARCHAR(60) NULL AFTER full_name',
            'first_name'     => 'VARCHAR(60) NULL AFTER surname',
            'middle_name'    => 'VARCHAR(60) NULL AFTER first_name',
            'birthday'       => 'DATE NULL AFTER middle_name',
            'must_change_pw' => 'TINYINT(1) NOT NULL DEFAULT 0',
            'active'         => 'TINYINT(1) NOT NULL DEFAULT 1'];
    foreach ($add as $col => $def) if (!$has($col)) $pdo->exec("ALTER TABLE staff ADD COLUMN $col $def");
    $pdo->exec('CREATE TABLE IF NOT EXISTS staff_calls (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        staff_id INT UNSIGNED NOT NULL,
        called_by INT UNSIGNED NOT NULL,
        destination VARCHAR(80) NOT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        KEY idx_created (created_at),
        KEY idx_staff (staff_id, created_at),
        FOREIGN KEY (staff_id) REFERENCES staff(id),
        FOREIGN KEY (called_by) REFERENCES staff(id)
    ) ENGINE=InnoDB');
    $_SESSION['schema_ok'] = true;
}

class HttpError extends RuntimeException {}
function fail(string $m, int $c = 400): never { throw new HttpError($m, $c); }
function out(array $d, int $code = 200): never {
    http_response_code($code);
    echo json_encode($d, JSON_UNESCAPED_UNICODE);
    exit;
}
function body(): array {
    $j = json_decode(file_get_contents('php://input') ?: '', true);
    return is_array($j) ? $j : [];
}
function staff(): ?array {
    static $s = false;
    if ($s !== false) return $s;
    if (empty($_SESSION['staff_id'])) return $s = null;
    $st = db()->prepare('SELECT s.id, s.full_name name, s.is_admin, s.unit_id, u.name unit, u.code unit_code, s.must_change_pw, s.active
                         FROM staff s JOIN units u ON u.id = s.unit_id WHERE s.id = ?');
    $st->execute([$_SESSION['staff_id']]);
    $r = $st->fetch();
    if (!$r || !(int)$r['active']) return $s = null;
    $r['must_change_pw'] = (bool)$r['must_change_pw']; unset($r['active']);
    $r['id'] = (int)$r['id']; $r['unit_id'] = (int)$r['unit_id']; $r['is_admin'] = (bool)$r['is_admin'];
    return $s = $r;
}
function need_staff(): array {
    $s = staff();
    if (!$s) fail('Mag-login muna.', 401);
    global $action;
    if ($s['must_change_pw'] && $action !== 'change_password') fail('Palitan muna ang temporary password mo.', 403);
    return $s;
}
function need_admin(): array {
    $s = need_staff();
    if (!$s['is_admin']) fail('Admin lang ang pwede dito.', 403);
    return $s;
}
function is_front(array $s): bool { return $s['is_admin'] || $s['unit_code'] === 'FRONT'; }
function need_front(): array {
    $s = need_staff();
    if (!is_front($s)) fail('Front Desk lang ang pwedeng tumawag ng empleyado.', 403);
    return $s;
}
// ---------- Admin helpers ----------
function temp_password(): string {
    $a = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789'; $p = '';
    for ($i = 0; $i < 10; $i++) $p .= $a[random_int(0, strlen($a) - 1)];
    return $p;
}
function clean_name(string $s, int $max): string { return mb_substr(preg_replace('/\s+/u', ' ', trim($s)), 0, $max); }
function ascii_slug(string $s): string {
    $s = strtr(mb_strtolower($s), ['ñ'=>'n','á'=>'a','à'=>'a','é'=>'e','è'=>'e','í'=>'i','ó'=>'o','ú'=>'u','ü'=>'u']);
    return preg_replace('/[^a-z0-9]/', '', $s);
}
/** username = unang letra ng first name + surname (hal. jdelacruz); dinadagdagan ng numero kung may kapareho. */
function make_username(string $first, string $sur, array &$taken): string {
    $base = substr(ascii_slug(mb_substr($first, 0, 1) . $sur), 0, 30);
    if ($base === '') $base = 'user';
    $chk = db()->prepare('SELECT 1 FROM staff WHERE username = ?');
    $u = $base; $n = 1;
    while (true) {
        if (!isset($taken[$u])) { $chk->execute([$u]); if (!$chk->fetch()) break; }
        $n++; $u = $base . $n;
    }
    $taken[$u] = true;
    return $u;
}
/** @return string|null|false  'Y-m-d' | null (blangko) | false (hindi tama) */
function parse_bday(string $v) {
    $v = trim($v);
    if ($v === '') return null;
    $d = DateTime::createFromFormat('!Y-m-d', $v);
    if (!$d || $d->format('Y-m-d') !== $v || (int)$d->format('Y') < 1900 || $d > new DateTime('today')) return false;
    return $v;
}
function find_unit(string $v): ?int {
    $like = str_replace(['%', '_'], '', $v) . ' (%';
    $st = db()->prepare('SELECT id FROM units WHERE code = ? OR name = ? OR name LIKE ? ORDER BY (name = ?) DESC, id LIMIT 1');
    $st->execute([$v, $v, $like, $v]);
    $id = $st->fetchColumn();
    return $id ? (int)$id : null;
}
function auto_code(string $name): string {
    $w = preg_split('/[^A-Za-z0-9]+/', strtoupper(ascii_slug_keepcase($name)), -1, PREG_SPLIT_NO_EMPTY) ?: [];
    $c = count($w) >= 2 ? implode('', array_map(fn($x) => $x[0], $w)) : substr($w[0] ?? '', 0, 8);
    $c = substr($c, 0, 10);
    if (strlen($c) < 2) $c = 'DIV';
    $chk = db()->prepare('SELECT 1 FROM units WHERE code = ?');
    $u = $c; $n = 1;
    while (true) { $chk->execute([$u]); if (!$chk->fetch()) return $u; $n++; $u = $c . $n; }
}
function ascii_slug_keepcase(string $s): string {
    return strtr($s, ['ñ'=>'n','Ñ'=>'N','á'=>'a','é'=>'e','í'=>'i','ó'=>'o','ú'=>'u','Á'=>'A','É'=>'E','Í'=>'I','Ó'=>'O','Ú'=>'U']);
}
function create_unit(string $name, string $code = ''): int {
    $code = strtoupper($code) ?: auto_code($name);
    db()->prepare('INSERT INTO units (code, name) VALUES (?,?)')->execute([$code, $name]);
    return (int)db()->lastInsertId();
}
function insert_staff(string $username, string $first, string $sur, string $mid, ?string $bd, int $unit, int $admin): string {
    $tmp = temp_password();
    db()->prepare('INSERT INTO staff (username, password_hash, full_name, surname, first_name, middle_name, birthday, unit_id, is_admin, must_change_pw)
                   VALUES (?,?,?,?,?,?,?,?,?,1)')
        ->execute([$username, password_hash($tmp, PASSWORD_DEFAULT), trim($first . ' ' . $sur), $sur ?: null, $first, $mid ?: null, $bd, $unit, $admin]);
    return $tmp;
}
function mask_name(string $n): string {
    $parts = preg_split('/\s+/u', trim($n)) ?: [];
    foreach ($parts as $i => $p) {
        $f = mb_substr($p, 0, 1);
        $parts[$i] = ($i === 0 && count($parts) > 1) ? $f . '***' : (mb_strlen($p) > 1 ? $f . '.' : $p);
    }
    return implode(' ', $parts);
}
function valid_ref(string $r): bool { return (bool)preg_match('/^DAR-\d{6}-[A-Z0-9]{4}$/', $r); }
function new_ref(): string {
    $alpha = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $s = '';
    for ($i = 0; $i < 4; $i++) $s .= $alpha[random_int(0, strlen($alpha) - 1)];
    return 'DAR-' . date('ymd') . '-' . $s;
}
function log_event(int $tid, ?int $step, string $action, ?int $staffId, ?string $rem = null): void {
    db()->prepare('INSERT INTO ticket_events (ticket_id, step_no, action, staff_id, remarks) VALUES (?,?,?,?,?)')
        ->execute([$tid, $step, $action, $staffId, $rem]);
}

/** Buong detalye ng ticket + ruta. $me = staff na nakatingin (para sa can_act / can_checkin). */
function ticket_full(string $ref, ?array $me = null): ?array {
    $pdo = db();
    $st = $pdo->prepare("SELECT t.id, t.ref_no ref, CONCAT(IF(t.ticket_type='A','AT',t.ticket_type),'-',LPAD(t.queue_no,3,'0')) q,
                                t.ticket_type type, t.full_name name, sv.name service, t.appt_at, t.status
                         FROM tickets t JOIN services sv ON sv.id = t.service_id WHERE t.ref_no = ?");
    $st->execute([$ref]);
    $t = $st->fetch();
    if (!$t) return null;
    $s2 = $pdo->prepare('SELECT ts.step_no, ts.label, ts.state, ts.unit_id, u.name unit
                         FROM ticket_steps ts JOIN units u ON u.id = ts.unit_id
                         WHERE ts.ticket_id = ? ORDER BY ts.step_no');
    $s2->execute([$t['id']]);
    $steps = $s2->fetchAll();
    $cur = null;
    foreach ($steps as &$x) {
        $x['step_no'] = (int)$x['step_no']; $x['unit_id'] = (int)$x['unit_id'];
        if ($cur === null && in_array($x['state'], ['waiting', 'processing'], true)) $cur = $x;
    }
    unset($x);
    $t['status']  = (int)$t['status'];
    $t['when']    = $t['appt_at'] ? substr($t['appt_at'], 0, 16) : '';
    $t['steps']   = $steps;
    $t['current'] = $cur ? $cur['step_no'] : null;
    $t['can_act'] = $t['status'] === 1 && $cur && $me && ($me['is_admin'] || $cur['unit_id'] === $me['unit_id']);
    $t['can_checkin'] = $t['status'] === 0 && $me && ($me['is_admin'] || $steps[0]['unit_id'] === $me['unit_id']);
    $t['first_unit'] = $steps[0]['unit'] ?? '';
    unset($t['id'], $t['appt_at']);
    return $t;
}

$action = $_GET['action'] ?? '';
$in = body();

try {
    ensure_schema();
    switch ($action) {

    case 'services':
        out(['services' => db()->query('SELECT id, name FROM services WHERE active=1 ORDER BY id')->fetchAll()]);

    // ---------- Client: gumawa ng ticket / appointment ----------
    case 'create':
        $name = trim((string)($in['name'] ?? ''));
        $type = (string)($in['type'] ?? 'T');
        $sid  = (int)($in['service_id'] ?? 0);
        $contact = substr(preg_replace('/[^\d+\- ]/', '', (string)($in['contact'] ?? '')), 0, 30);
        if (mb_strlen($name) < 3 || mb_strlen($name) > 120) fail('Ilagay ang buong pangalan.', 422);
        if (!in_array($type, ['T', 'A'], true)) fail('Maling uri.', 422);

        $st = db()->prepare('SELECT 1 FROM services WHERE id=? AND active=1');
        $st->execute([$sid]);
        if (!$st->fetch()) fail('Pumili ng serbisyo.', 422);

        $apptAt = null; $qdate = date('Y-m-d');
        if ($type === 'A') {
            $d = (string)($in['date'] ?? ''); $tm = (string)($in['time'] ?? '');
            $dt = DateTime::createFromFormat('Y-m-d', $d);
            $today = new DateTime('today'); $max = (clone $today)->modify('+' . APPT_MAX_DAYS . ' days');
            if (!$dt || $dt->format('Y-m-d') !== $d || $dt < $today || $dt > $max) fail('Maling petsa ng appointment.', 422);
            if ((int)$dt->format('N') > 5) fail('Weekdays lang ang appointment.', 422);
            if (!in_array($tm, APPT_HOURS, true)) fail('Maling oras.', 422);
            if ($d === date('Y-m-d') && $tm <= date('H:i')) fail('Lumipas na ang oras na iyan. Pumili ng mas huli.', 422);
            $apptAt = "$d $tm:00"; $qdate = $d;
            $c = db()->prepare('SELECT COUNT(*) FROM tickets WHERE ticket_type="A" AND appt_at=?');
            $c->execute([$apptAt]);
            if ((int)$c->fetchColumn() >= SLOT_CAPACITY) fail('Puno na ang oras na iyan. Pumili ng iba.', 409);
        }

        $pdo = db();
        for ($try = 0; $try < 5; $try++) {
            try {
                $pdo->beginTransaction();
                $pdo->prepare('INSERT INTO queue_counters (queue_date, ticket_type, last_no) VALUES (?,?,LAST_INSERT_ID(1))
                               ON DUPLICATE KEY UPDATE last_no = LAST_INSERT_ID(last_no + 1)')->execute([$qdate, $type]);
                $no  = (int)$pdo->query('SELECT LAST_INSERT_ID()')->fetchColumn();
                $ref = new_ref();
                $pdo->prepare('INSERT INTO tickets (ref_no, queue_date, queue_no, ticket_type, full_name, contact_no, service_id, appt_at)
                               VALUES (?,?,?,?,?,?,?,?)')->execute([$ref, $qdate, $no, $type, $name, $contact, $sid, $apptAt]);
                $tid = (int)$pdo->lastInsertId();
                // kopyahin ang workflow ng serbisyo papunta sa ticket
                $cp = $pdo->prepare('INSERT INTO ticket_steps (ticket_id, step_no, unit_id, label)
                                     SELECT ?, step_no, unit_id, label FROM service_steps WHERE service_id = ?');
                $cp->execute([$tid, $sid]);
                if ($cp->rowCount() < 1) fail('Wala pang workflow ang serbisyong ito. Kausapin ang admin.', 500);
                $pdo->commit();
                out(['ticket' => ticket_full($ref)], 201);
            } catch (PDOException $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                if ($e->getCode() !== '23000') throw $e;      // duplicate ref -> ulit
            }
        }
        fail('Hindi nakagawa ng ticket. Subukan ulit.', 500);

    // ---------- Client: bakanteng oras ng appointment sa isang petsa ----------
    case 'slots':
        $d  = (string)($in['date'] ?? ($_GET['date'] ?? ''));
        $dt = DateTime::createFromFormat('Y-m-d', $d);
        $today = new DateTime('today'); $max = (clone $today)->modify('+' . APPT_MAX_DAYS . ' days');
        if (!$dt || $dt->format('Y-m-d') !== $d || $dt < $today || $dt > $max) fail('Maling petsa ng appointment.', 422);
        if ((int)$dt->format('N') > 5) fail('Weekdays lang ang appointment.', 422);
        $c = db()->prepare("SELECT TIME_FORMAT(TIME(appt_at), '%H:%i') h, COUNT(*) n FROM tickets
                            WHERE ticket_type = 'A' AND DATE(appt_at) = ? GROUP BY h");
        $c->execute([$d]);
        $used = [];
        foreach ($c->fetchAll() as $r) $used[$r['h']] = (int)$r['n'];
        $isToday = $d === date('Y-m-d'); $nowHm = date('H:i');
        $slots = [];
        foreach (APPT_HOURS as $h) {
            $left = max(0, SLOT_CAPACITY - ($used[$h] ?? 0));
            if ($isToday && $h <= $nowHm) $left = 0;
            $slots[] = ['time' => $h, 'left' => $left];
        }
        out(['slots' => $slots]);

    // ---------- Client (public): subaybayan ang status ng ticket gamit ang reference no. / QR ----------
    // Naka-mask ang pangalan; ang reference number ang "susi". May rate limit para hindi mahulaan.
    case 'track':
        $ref = strtoupper(trim((string)($in['ref'] ?? ($_GET['ref'] ?? ''))));
        if (!valid_ref($ref)) fail('Hindi tamang format ng reference number.', 422);
        $now = time();
        $_SESSION['trk'] = array_values(array_filter($_SESSION['trk'] ?? [], fn($x) => $x > $now - 60));
        if (count($_SESSION['trk']) >= 40) fail('Masyadong madalas ang paghahanap. Maghintay sandali.', 429);
        $_SESSION['trk'][] = $now;

        $pdo = db();
        $st = $pdo->prepare("SELECT t.id, t.ref_no ref, CONCAT(IF(t.ticket_type='A','AT',t.ticket_type),'-',LPAD(t.queue_no,3,'0')) q, t.ticket_type type,
                                    t.full_name name, sv.name service, t.appt_at, t.status
                             FROM tickets t JOIN services sv ON sv.id = t.service_id WHERE t.ref_no = ?");
        $st->execute([$ref]);
        $t = $st->fetch();
        if (!$t) { usleep(400000); fail('Walang nahanap na ticket para sa reference number na ito.', 404); }

        $s2 = $pdo->prepare('SELECT ts.step_no, ts.label, ts.state, ts.unit_id, u.name unit, ts.ready_at, ts.started_at, ts.finished_at
                             FROM ticket_steps ts JOIN units u ON u.id = ts.unit_id WHERE ts.ticket_id = ? ORDER BY ts.step_no');
        $s2->execute([$t['id']]);
        $steps = []; $cur = null; $done = 0;
        foreach ($s2->fetchAll() as $x) {
            $at = match ($x['state']) { 'done' => $x['finished_at'], 'processing' => $x['started_at'], 'waiting' => $x['ready_at'], default => null };
            $row = ['no' => (int)$x['step_no'], 'unit' => $x['unit'], 'label' => $x['label'], 'state' => $x['state'], 'at' => $at];
            if ($x['state'] === 'done') $done++;
            if ($cur === null && in_array($x['state'], ['waiting', 'processing'], true)) $cur = $row + ['unit_id' => (int)$x['unit_id'], 'ready_at' => $x['ready_at']];
            $steps[] = $row;
        }
        $status = (int)$t['status'];
        $phase  = $status === 0 ? 'registered' : ($status === 2 ? 'completed' : ($cur['state'] ?? 'waiting'));

        // ilan ang nauuna sa pila ng kasalukuyang opisina
        $ahead = null;
        if ($status === 1 && $cur && $cur['state'] === 'waiting') {
            $a = $pdo->prepare("SELECT COUNT(*) FROM ticket_steps ts JOIN tickets x ON x.id = ts.ticket_id
                                WHERE x.status = 1 AND ts.unit_id = ? AND ts.ticket_id <> ? AND ts.state IN ('waiting','processing')
                                  AND (ts.state = 'processing' OR ts.ready_at < ?)");
            $a->execute([$cur['unit_id'], $t['id'], $cur['ready_at']]);
            $ahead = (int)$a->fetchColumn();
        }
        // kung ibinalik ang ticket sa nakaraang hakbang, ipakita ang dahilan
        $e = $pdo->prepare('SELECT action, remarks FROM ticket_events WHERE ticket_id = ? ORDER BY id DESC LIMIT 1');
        $e->execute([$t['id']]);
        $ev = $e->fetch();
        $note = ($ev && $ev['action'] === 'return' && $ev['remarks']) ? $ev['remarks'] : '';

        out(['ticket' => [
            'ref' => $t['ref'], 'q' => $t['q'], 'type' => $t['type'], 'name' => mask_name($t['name']), 'service' => $t['service'],
            'when' => $t['appt_at'] ? substr($t['appt_at'], 0, 16) : '', 'status' => $status, 'phase' => $phase,
            'unit' => $cur['unit'] ?? '', 'label' => $cur['label'] ?? '', 'ahead' => $ahead, 'note' => $note,
            'done' => $done, 'total' => count($steps), 'steps' => $steps,
            'last_unit' => $steps ? $steps[count($steps) - 1]['unit'] : '', 'server_time' => date('Y-m-d H:i:s'),
        ]]);

    // ---------- Staff ----------
    case 'login':
        $st = db()->prepare('SELECT id, password_hash, active FROM staff WHERE username=?');
        $st->execute([trim((string)($in['username'] ?? ''))]);
        $u = $st->fetch();
        if (!$u || !password_verify((string)($in['password'] ?? ''), $u['password_hash'])) {
            sleep(1);
            fail('Maling username o password.', 401);
        }
        if (!(int)$u['active']) fail('Naka-disable ang account na ito. Kausapin ang admin.', 403);
        session_regenerate_id(true);
        $_SESSION['staff_id'] = (int)$u['id'];
        out(['staff' => staff()]);

    case 'logout':
        $_SESSION = []; session_destroy();
        out(['ok' => true]);

    case 'me':
        out(['staff' => staff()]);

    // Scan/type ng ref: tingnan ang ticket; kung Nakarehistro pa at ang opisina mo ang unang hakbang -> auto check-in
    case 'scan':
        $me  = need_staff();
        $ref = strtoupper(trim((string)($in['ref'] ?? '')));
        if (!valid_ref($ref)) fail('Hindi tamang format ng reference number.', 422);
        $t = ticket_full($ref, $me);
        if (!$t) fail('Walang nahanap na ticket para sa reference number na ito.', 404);
        // Hindi makikita ng ibang opisina ang ticket na wala sa kanila ngayon (admin lang ang exempted)
        if (!$me['is_admin'] && !$t['can_act'] && !$t['can_checkin']) fail('Hindi ito ticket ng opisina mo sa ngayon.', 403);
        $checked = false;
        if ($t['can_checkin']) {
            if ($t['when'] && substr($t['when'], 0, 10) !== date('Y-m-d')) {
                fail('Hindi pa ito ang araw ng appointment (' . $t['when'] . ').', 409);
            }
            $pdo = db();
            $pdo->beginTransaction();
            $st = $pdo->prepare('SELECT id, status FROM tickets WHERE ref_no=? FOR UPDATE');
            $st->execute([$ref]);
            $row = $st->fetch();
            if ((int)$row['status'] === 0) {
                $pdo->prepare('UPDATE tickets SET status=1 WHERE id=?')->execute([$row['id']]);
                $pdo->prepare("UPDATE ticket_steps SET state='waiting', ready_at=NOW() WHERE ticket_id=? AND step_no=1")->execute([$row['id']]);
                log_event((int)$row['id'], 1, 'checkin', $me['id']);
                $checked = true;
            }
            $pdo->commit();
            $t = ticket_full($ref, $me);
        }
        out(['ticket' => $t, 'checked_in' => $checked]);

    // Aksyon sa kasalukuyang hakbang: start | done (ipasa sa susunod) | return (ibalik sa nakaraan)
    case 'step':
        $me  = need_staff();
        $ref = strtoupper(trim((string)($in['ref'] ?? '')));
        $op  = (string)($in['op'] ?? '');
        $rem = mb_substr(trim((string)($in['remarks'] ?? '')), 0, 255);
        if (!valid_ref($ref) || !in_array($op, ['start', 'done', 'return'], true)) fail('Maling request.', 422);

        $pdo = db();
        $pdo->beginTransaction();
        $st = $pdo->prepare('SELECT id, status FROM tickets WHERE ref_no=? FOR UPDATE');
        $st->execute([$ref]);
        $t = $st->fetch();
        if (!$t) fail('Walang nahanap na ticket.', 404);
        if ((int)$t['status'] !== 1) fail('Hindi pa naka-check in o tapos na ang ticket.', 409);
        $tid = (int)$t['id'];

        $c = $pdo->prepare("SELECT step_no, unit_id, state FROM ticket_steps
                            WHERE ticket_id=? AND state IN ('waiting','processing') ORDER BY step_no LIMIT 1 FOR UPDATE");
        $c->execute([$tid]);
        $cur = $c->fetch();
        if (!$cur) fail('Walang aktibong hakbang.', 409);
        if (!$me['is_admin'] && (int)$cur['unit_id'] !== $me['unit_id']) fail('Hindi ang opisina mo ang may hawak ng ticket na ito.', 403);
        $n = (int)$cur['step_no'];

        if ($op === 'start') {
            if ($cur['state'] !== 'waiting') fail('Nasimulan na ang hakbang na ito.', 409);
            $pdo->prepare("UPDATE ticket_steps SET state='processing', started_at=NOW(), staff_id=? WHERE ticket_id=? AND step_no=?")
                ->execute([$me['id'], $tid, $n]);
        } elseif ($op === 'done') {
            if ($cur['state'] !== 'processing') fail('I-click muna ang "Simulan" bago tapusin.', 409);
            $pdo->prepare("UPDATE ticket_steps SET state='done', finished_at=NOW(), staff_id=? WHERE ticket_id=? AND step_no=?")
                ->execute([$me['id'], $tid, $n]);
            $nx = $pdo->prepare("UPDATE ticket_steps SET state='waiting', ready_at=NOW() WHERE ticket_id=? AND step_no=?");
            $nx->execute([$tid, $n + 1]);
            if ($nx->rowCount() === 0) $pdo->prepare('UPDATE tickets SET status=2 WHERE id=?')->execute([$tid]);   // huling hakbang
        } else {
            if ($n <= 1) fail('Wala nang nakaraang hakbang.', 409);
            if ($rem === '') fail('Maglagay ng remarks kung bakit ibabalik.', 422);
            $pdo->prepare("UPDATE ticket_steps SET state='pending', started_at=NULL, staff_id=NULL WHERE ticket_id=? AND step_no=?")
                ->execute([$tid, $n]);
            $pdo->prepare("UPDATE ticket_steps SET state='waiting', ready_at=NOW(), started_at=NULL, finished_at=NULL WHERE ticket_id=? AND step_no=?")
                ->execute([$tid, $n - 1]);
        }
        log_event($tid, $n, $op, $me['id'], $rem ?: null);
        $pdo->commit();
        out(['ticket' => ticket_full($ref, $me)]);

    // Pila ng opisina ko (admin: lahat)
    case 'queue':
        $me = need_staff();
        $sql = "SELECT t.ref_no ref, CONCAT(IF(t.ticket_type='A','AT',t.ticket_type),'-',LPAD(t.queue_no,3,'0')) q, t.full_name name,
                       sv.name service, ts.label, ts.state, u.name unit
                FROM tickets t
                JOIN services sv ON sv.id = t.service_id
                JOIN ticket_steps ts ON ts.ticket_id = t.id AND ts.state IN ('waiting','processing')
                JOIN units u ON u.id = ts.unit_id
                WHERE t.status = 1";
        $args = [];
        if (!$me['is_admin']) { $sql .= ' AND ts.unit_id = ?'; $args[] = $me['unit_id']; }
        $st = db()->prepare($sql . " ORDER BY (ts.state='processing') DESC, ts.ready_at LIMIT 200");
        $st->execute($args);
        out(['rows' => $st->fetchAll()]);

    // Mga ticket ngayon. Staff: ang mga ticket lang na nasa opisina nila (o hinihintay ang check-in nila). Admin: lahat.
    case 'list':
        $me = need_staff();
        $sql = "SELECT t.ref_no ref, CONCAT(IF(t.ticket_type='A','AT',t.ticket_type),'-',LPAD(t.queue_no,3,'0')) q, t.full_name name,
                       sv.name service, t.status, u.name unit, ts.state
                FROM tickets t JOIN services sv ON sv.id = t.service_id
                LEFT JOIN ticket_steps ts ON ts.ticket_id = t.id AND ts.state IN ('waiting','processing')
                LEFT JOIN units u ON u.id = ts.unit_id
                WHERE t.queue_date = CURDATE()";
        $args = [];
        if (!$me['is_admin']) {
            $sql .= " AND (ts.unit_id = ? OR (t.status = 0 AND EXISTS (
                         SELECT 1 FROM ticket_steps s1 WHERE s1.ticket_id = t.id AND s1.step_no = 1 AND s1.unit_id = ?)))";
            $args = [$me['unit_id'], $me['unit_id']];
        }
        $st = db()->prepare($sql . ' ORDER BY t.id DESC LIMIT 200');
        $st->execute($args);
        out(['rows' => $st->fetchAll()]);

    // ---------- TV (public, naka-mask ang pangalan) ----------
    case 'board':
        $pdo = db();
        $ts = $pdo->query("SELECT t.id, CONCAT(IF(t.ticket_type='A','AT',t.ticket_type),'-',LPAD(t.queue_no,3,'0')) q, t.full_name name, sv.name service, t.status
                           FROM tickets t JOIN services sv ON sv.id = t.service_id
                           WHERE t.queue_date = CURDATE() AND NOT (t.ticket_type = 'A' AND t.status = 0)
                             AND (t.status < 2 OR t.updated_at > NOW() - INTERVAL 30 MINUTE)
                           ORDER BY CASE t.status WHEN 1 THEN 0 WHEN 0 THEN 1 ELSE 2 END, t.id LIMIT 150")->fetchAll();
        $rows = [];
        if ($ts) {
            $ids = array_map(fn($r) => (int)$r['id'], $ts);
            $in2 = implode(',', array_fill(0, count($ids), '?'));
            $q = $pdo->prepare("SELECT ts.ticket_id, ts.step_no, ts.state, u.name unit FROM ticket_steps ts
                                JOIN units u ON u.id = ts.unit_id WHERE ts.ticket_id IN ($in2) ORDER BY ts.step_no");
            $q->execute($ids);
            $by = [];
            foreach ($q->fetchAll() as $s) $by[$s['ticket_id']][] = $s;
            foreach ($ts as $t) {
                $steps = $by[$t['id']] ?? [];
                $done = 0; $unit = ''; $phase = $t['status'] == 0 ? 'registered' : 'completed';
                foreach ($steps as $s) {
                    if ($s['state'] === 'done') $done++;
                    if ($t['status'] == 1 && $unit === '' && in_array($s['state'], ['waiting', 'processing'], true)) {
                        $unit = $s['unit']; $phase = $s['state'];
                    }
                }
                $rows[] = ['q' => $t['q'], 'name' => mask_name($t['name']), 'service' => $t['service'],
                           'phase' => $phase, 'unit' => $unit, 'done' => $done, 'total' => count($steps)];
            }
        }
        out(['rows' => $rows]);

    // ---------- Call Employee (Front Desk / Admin) ----------
    case 'employees':
        need_front();
        $rows = db()->query('SELECT s.id, s.full_name name, u.name unit FROM staff s JOIN units u ON u.id = s.unit_id
                             WHERE s.active = 1 ORDER BY u.id, s.full_name')->fetchAll();
        foreach ($rows as &$r) $r['id'] = (int)$r['id'];
        unset($r);
        out(['rows' => $rows]);

    case 'call_employee':
        $me  = need_front();
        $sid = (int)($in['staff_id'] ?? 0);
        $dest = mb_substr(trim((string)($in['destination'] ?? '')), 0, 80);
        if ($dest === '') $dest = $me['unit'];
        $st = db()->prepare('SELECT s.id, s.full_name name, u.name unit FROM staff s JOIN units u ON u.id = s.unit_id WHERE s.id = ? AND s.active = 1');
        $st->execute([$sid]);
        $emp = $st->fetch();
        if (!$emp) fail('Pumili ng empleyado.', 422);
        $dup = db()->prepare('SELECT 1 FROM staff_calls WHERE staff_id = ? AND created_at > NOW() - INTERVAL 5 SECOND');
        $dup->execute([$sid]);
        if ($dup->fetch()) fail('Katatawag lang. Maghintay ng ilang segundo bago ulitin.', 429);
        db()->prepare('INSERT INTO staff_calls (staff_id, called_by, destination) VALUES (?,?,?)')->execute([$sid, $me['id'], $dest]);
        out(['call' => ['id' => (int)db()->lastInsertId(), 'name' => $emp['name'], 'unit' => $emp['unit'], 'destination' => $dest]], 201);

    case 'call_log':
        need_front();
        $rows = db()->query("SELECT c.id, c.staff_id, s.full_name name, c.destination, DATE_FORMAT(c.created_at,'%H:%i') t, cb.full_name by_name
                             FROM staff_calls c JOIN staff s ON s.id = c.staff_id JOIN staff cb ON cb.id = c.called_by
                             WHERE c.created_at >= CURDATE() ORDER BY c.id DESC LIMIT 10")->fetchAll();
        foreach ($rows as &$r) $r['staff_id'] = (int)$r['staff_id'];
        unset($r);
        out(['rows' => $rows]);

    // TV polling. since=-1 -> ibigay lang ang pinakabagong id (para hindi ma-replay ang mga lumang tawag pag nag-refresh ang TV)
    case 'calls':
        $since  = (int)($_GET['since'] ?? -1);
        $latest = (int)db()->query('SELECT COALESCE(MAX(id),0) FROM staff_calls')->fetchColumn();
        if ($since < 0) out(['calls' => [], 'latest' => $latest]);
        $st = db()->prepare('SELECT c.id, s.full_name name, u.name unit, c.destination
                             FROM staff_calls c JOIN staff s ON s.id = c.staff_id JOIN units u ON u.id = s.unit_id
                             WHERE c.id > ? AND c.created_at > NOW() - INTERVAL 2 MINUTE ORDER BY c.id LIMIT 10');
        $st->execute([$since]);
        $rows = $st->fetchAll();
        foreach ($rows as &$r) $r['id'] = (int)$r['id'];
        unset($r);
        out(['calls' => $rows, 'latest' => $latest]);

    // ---------- Palitan ang sariling password (kailangan din sa unang login ng bagong account) ----------
    case 'change_password':
        $me = need_staff();
        $old = (string)($in['current'] ?? ''); $new = (string)($in['new'] ?? '');
        $st = db()->prepare('SELECT password_hash FROM staff WHERE id = ?'); $st->execute([$me['id']]);
        if (!password_verify($old, (string)$st->fetchColumn())) { sleep(1); fail('Mali ang kasalukuyang password.', 401); }
        if (mb_strlen($new) < 8) fail('Ang bagong password ay hindi bababa sa 8 characters.', 422);
        if ($new === $old) fail('Dapat iba ang bagong password.', 422);
        db()->prepare('UPDATE staff SET password_hash = ?, must_change_pw = 0 WHERE id = ?')
            ->execute([password_hash($new, PASSWORD_DEFAULT), $me['id']]);
        session_regenerate_id(true);
        out(['ok' => true]);

    // ================= ADMIN =================
    case 'admin_staff':
        need_admin();
        $rows = db()->query('SELECT s.id, s.username, s.full_name, s.surname, s.first_name, s.middle_name, s.birthday,
                                    s.unit_id, u.name unit, s.is_admin, s.active, s.must_change_pw
                             FROM staff s JOIN units u ON u.id = s.unit_id ORDER BY s.active DESC, s.full_name')->fetchAll();
        foreach ($rows as &$r) { foreach (['id','unit_id'] as $k) $r[$k] = (int)$r[$k]; foreach (['is_admin','active','must_change_pw'] as $k) $r[$k] = (bool)$r[$k]; }
        unset($r);
        out(['rows' => $rows]);

    case 'admin_staff_save':
        $me  = need_admin();
        $id  = (int)($in['id'] ?? 0);
        $sur = clean_name((string)($in['surname'] ?? ''), 60);
        $fn  = clean_name((string)($in['first_name'] ?? ''), 60);
        $mid = clean_name((string)($in['middle_name'] ?? ''), 60);
        $bd  = parse_bday((string)($in['birthday'] ?? ''));
        $uid = (int)($in['unit_id'] ?? 0);
        $adm = !empty($in['is_admin']) ? 1 : 0;
        if ($fn === '') fail('Ilagay ang First Name.', 422);
        if ($bd === false) fail('Hindi tamang birthday.', 422);
        $c = db()->prepare('SELECT 1 FROM units WHERE id = ?'); $c->execute([$uid]);
        if (!$c->fetch()) fail('Pumili ng division.', 422);
        if ($id) {
            $c = db()->prepare('SELECT 1 FROM staff WHERE id = ?'); $c->execute([$id]);
            if (!$c->fetch()) fail('Walang nahanap na account.', 404);
            if ($id === $me['id'] && !$adm) fail('Hindi mo pwedeng alisin ang sarili mong admin role.', 409);
            db()->prepare('UPDATE staff SET full_name=?, surname=?, first_name=?, middle_name=?, birthday=?, unit_id=?, is_admin=? WHERE id=?')
                ->execute([trim($fn . ' ' . $sur), $sur ?: null, $fn, $mid ?: null, $bd, $uid, $adm, $id]);
            out(['ok' => true]);
        }
        if ($sur === '') fail('Ilagay ang Surname.', 422);
        $un = trim((string)($in['username'] ?? ''));
        $taken = [];
        if ($un !== '') {
            if (!preg_match('/^[A-Za-z0-9._-]{3,40}$/', $un)) fail('Username: 3-40 characters (letters, numbers, . _ - lang).', 422);
            $c = db()->prepare('SELECT 1 FROM staff WHERE username = ?'); $c->execute([$un]);
            if ($c->fetch()) fail('May gumagamit na ng username na iyan.', 409);
        } else {
            $un = make_username($fn, $sur, $taken);
        }
        $tmp = insert_staff($un, $fn, $sur, $mid, $bd, $uid, $adm);
        out(['username' => $un, 'temp_password' => $tmp, 'name' => trim($fn . ' ' . $sur)], 201);

    case 'admin_staff_active':
        $me = need_admin();
        $id = (int)($in['id'] ?? 0); $act = !empty($in['active']) ? 1 : 0;
        if ($id === $me['id'] && !$act) fail('Hindi mo pwedeng i-disable ang sarili mong account.', 409);
        $st = db()->prepare('UPDATE staff SET active = ? WHERE id = ?'); $st->execute([$act, $id]);
        out(['ok' => true]);

    case 'admin_staff_reset':
        need_admin();
        $id = (int)($in['id'] ?? 0);
        $st = db()->prepare('SELECT username FROM staff WHERE id = ?'); $st->execute([$id]);
        $un = $st->fetchColumn();
        if (!$un) fail('Walang nahanap na account.', 404);
        $tmp = temp_password();
        db()->prepare('UPDATE staff SET password_hash = ?, must_change_pw = 1 WHERE id = ?')->execute([password_hash($tmp, PASSWORD_DEFAULT), $id]);
        out(['username' => $un, 'temp_password' => $tmp]);

    // Excel import. rows = [{surname, first_name, middle_name, birthday, division}]. dry_run = preview lang (walang sine-save).
    case 'admin_import':
        need_admin();
        $rows = $in['rows'] ?? [];
        $dry  = !empty($in['dry_run']); $mk = !empty($in['create_divisions']);
        if (!is_array($rows) || !$rows) fail('Walang laman ang file.', 422);
        if (count($rows) > ($dry ? 1000 : 100)) fail('Masyadong maraming rows sa isang request.', 422);
        $taken = []; $seen = []; $newDivs = []; $res = [];
        $dupq = db()->prepare('SELECT 1 FROM staff WHERE surname = ? AND first_name = ? AND birthday <=> ? LIMIT 1');
        foreach ($rows as $i => $r) {
            $r   = is_array($r) ? $r : [];
            $sur = clean_name((string)($r['surname'] ?? ''), 60);
            $fn  = clean_name((string)($r['first_name'] ?? ''), 60);
            $mid = clean_name((string)($r['middle_name'] ?? ''), 60);
            $div = clean_name((string)($r['division'] ?? ''), 80);
            $bd  = parse_bday((string)($r['birthday'] ?? ''));
            $line = ['row' => (int)($r['row'] ?? $i + 1), 'name' => trim($fn . ' ' . $sur), 'division' => $div,
                     'birthday' => $bd ?: '', 'status' => 'error', 'note' => '', 'username' => '', 'temp_password' => ''];
            if ($sur === '' || $fn === '')      $line['note'] = 'Kulang ang Surname o First Name.';
            elseif ($bd === false)              $line['note'] = 'Hindi tamang birthday.';
            elseif ($div === '')                $line['note'] = 'Walang Division.';
            else {
                $uid = find_unit($div); $new = false;
                if (!$uid && isset($newDivs[mb_strtolower($div)])) { $new = true; $uid = $newDivs[mb_strtolower($div)]; }
                if (!$uid && $mk) {
                    $new = true;
                    $uid = $dry ? -1 : create_unit($div);
                    $newDivs[mb_strtolower($div)] = $uid;
                }
                $key = mb_strtolower("$sur|$fn|" . ($bd ?? ''));
                if (!$uid)                      $line['note'] = "Walang division na '$div'. (I-check ang \"Gumawa ng bagong division\" o idagdag muna sa Divisions.)";
                elseif (isset($seen[$key]))     { $line['status'] = 'skip'; $line['note'] = 'Doble sa file.'; }
                else {
                    $seen[$key] = true;
                    $dupq->execute([$sur, $fn, $bd]);
                    if ($dupq->fetch())         { $line['status'] = 'skip'; $line['note'] = 'May account na ang taong ito.'; }
                    else {
                        $un = make_username($fn, $sur, $taken);
                        $line['username'] = $un; $line['status'] = 'ok';
                        if ($new) $line['note'] = 'Gagawa ng bagong division.';
                        if (!$dry) $line['temp_password'] = insert_staff($un, $fn, $sur, $mid, $bd, $uid, 0);
                    }
                }
            }
            $res[] = $line;
        }
        out(['rows' => $res, 'dry_run' => $dry]);

    case 'admin_units':
        need_admin();
        $rows = db()->query('SELECT u.id, u.code, u.name,
                                    (SELECT COUNT(*) FROM staff s WHERE s.unit_id = u.id) staff_n,
                                    (SELECT COUNT(*) FROM service_steps x WHERE x.unit_id = u.id) steps_n,
                                    EXISTS(SELECT 1 FROM ticket_steps t WHERE t.unit_id = u.id) in_tickets
                             FROM units u ORDER BY u.id')->fetchAll();
        foreach ($rows as &$r) { foreach (['id','staff_n','steps_n'] as $k) $r[$k] = (int)$r[$k]; $r['in_tickets'] = (bool)$r['in_tickets']; }
        unset($r);
        out(['rows' => $rows]);

    case 'admin_unit_save':
        need_admin();
        $id = (int)($in['id'] ?? 0);
        $name = clean_name((string)($in['name'] ?? ''), 80);
        $code = strtoupper(trim((string)($in['code'] ?? '')));
        if (mb_strlen($name) < 2) fail('Ilagay ang pangalan ng division.', 422);
        $c = db()->prepare('SELECT 1 FROM units WHERE name = ? AND id <> ?'); $c->execute([$name, $id]);
        if ($c->fetch()) fail('May division nang ganyan ang pangalan.', 409);
        if ($id) {
            $c = db()->prepare('UPDATE units SET name = ? WHERE id = ?'); $c->execute([$name, $id]);   // code ay hindi na binabago
            out(['ok' => true]);
        }
        if ($code !== '') {
            if (!preg_match('/^[A-Z0-9]{2,12}$/', $code)) fail('Code: 2-12 letters/numbers lang.', 422);
            $c = db()->prepare('SELECT 1 FROM units WHERE code = ?'); $c->execute([$code]);
            if ($c->fetch()) fail('Ginagamit na ang code na iyan.', 409);
        }
        out(['id' => create_unit($name, $code)], 201);

    case 'admin_unit_delete':
        need_admin();
        $id = (int)($in['id'] ?? 0);
        $st = db()->prepare('SELECT code FROM units WHERE id = ?'); $st->execute([$id]);
        $code = $st->fetchColumn();
        if (!$code) fail('Walang nahanap na division.', 404);
        if ($code === 'FRONT') fail('Hindi pwedeng burahin ang Front Desk.', 409);
        foreach (['SELECT 1 FROM staff WHERE unit_id = ?', 'SELECT 1 FROM service_steps WHERE unit_id = ?', 'SELECT 1 FROM ticket_steps WHERE unit_id = ?'] as $q) {
            $c = db()->prepare($q . ' LIMIT 1'); $c->execute([$id]);
            if ($c->fetch()) fail('Ginagamit pa ang division na ito (may staff, workflow o ticket). Palitan muna bago burahin.', 409);
        }
        db()->prepare('DELETE FROM units WHERE id = ?')->execute([$id]);
        out(['ok' => true]);

    // Process / workflow ng bawat serbisyo (ticket type). Mga bagong ticket lang ang apektado.
    case 'admin_services':
        need_admin();
        $sv = db()->query('SELECT id, name, active FROM services ORDER BY id')->fetchAll();
        $by = [];
        foreach (db()->query('SELECT service_id, unit_id, label FROM service_steps ORDER BY service_id, step_no')->fetchAll() as $s)
            $by[(int)$s['service_id']][] = ['unit_id' => (int)$s['unit_id'], 'label' => $s['label']];
        foreach ($sv as &$r) { $r['id'] = (int)$r['id']; $r['active'] = (bool)$r['active']; $r['steps'] = $by[$r['id']] ?? []; }
        unset($r);
        out(['rows' => $sv]);

    case 'admin_service_save':
        need_admin();
        $id = (int)($in['id'] ?? 0);
        $name = clean_name((string)($in['name'] ?? ''), 120);
        $act = !empty($in['active']) ? 1 : 0;
        $steps = $in['steps'] ?? [];
        if (mb_strlen($name) < 3) fail('Ilagay ang pangalan ng serbisyo.', 422);
        if (!is_array($steps) || count($steps) < 1) fail('Kailangan ng kahit isang hakbang.', 422);
        if (count($steps) > 15) fail('Hanggang 15 hakbang lang.', 422);
        $pdo = db();
        $uq = $pdo->prepare('SELECT name FROM units WHERE id = ?');
        $clean = [];
        foreach ($steps as $n => $s) {
            $u = (int)($s['unit_id'] ?? 0); $uq->execute([$u]); $un = $uq->fetchColumn();
            if (!$un) fail('Pumili ng division sa hakbang #' . ($n + 1) . '.', 422);
            $lb = clean_name((string)($s['label'] ?? ''), 120);
            $clean[] = [$u, $lb !== '' ? $lb : $un];
        }
        $pdo->beginTransaction();
        if ($id) {
            $c = $pdo->prepare('SELECT 1 FROM services WHERE id = ?'); $c->execute([$id]);
            if (!$c->fetch()) fail('Walang nahanap na serbisyo.', 404);
            $pdo->prepare('UPDATE services SET name = ?, active = ? WHERE id = ?')->execute([$name, $act, $id]);
            $pdo->prepare('DELETE FROM service_steps WHERE service_id = ?')->execute([$id]);
        } else {
            $pdo->prepare('INSERT INTO services (name, active) VALUES (?,?)')->execute([$name, $act]);
            $id = (int)$pdo->lastInsertId();
        }
        $ins = $pdo->prepare('INSERT INTO service_steps (service_id, step_no, unit_id, label) VALUES (?,?,?,?)');
        foreach ($clean as $n => $c) $ins->execute([$id, $n + 1, $c[0], $c[1]]);
        $pdo->commit();
        out(['id' => $id]);

    default:
        fail('Unknown action', 404);
    }
} catch (HttpError $e) {
    try { if (db()->inTransaction()) db()->rollBack(); } catch (Throwable $x) {}
    out(['error' => $e->getMessage()], $e->getCode() ?: 400);
} catch (Throwable $e) {
    try { if (db()->inTransaction()) db()->rollBack(); } catch (Throwable $x) {}
    error_log('[DAR] ' . $e->getMessage());
    $res = ['error' => 'May problema sa server. Subukan ulit.'];
    if (DEBUG) $res['detail'] = get_class($e) . ': ' . $e->getMessage();
    out($res, 500);
}