<?php
declare(strict_types=1);
date_default_timezone_set('Asia/Manila');

const DB_HOST = '127.0.0.1';
const DB_NAME = 'dar_ticketing';
// XAMPP (local): root at walang password. Sa production: gumamit ng limited MySQL user, huwag root.
const DB_USER = 'root';
const DB_PASS = '';

const DEBUG = true;                 // true = ipakita ang totoong error sa browser. I-set sa false sa production!

const SLOT_CAPACITY = 5;            // max appointments per oras
const APPT_HOURS    = ['08:00','09:00','10:00','11:00','13:00','14:00','15:00'];
const APPT_MAX_DAYS = 30;

function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $pdo = new PDO(
            'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
            DB_USER, DB_PASS,
            [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET time_zone = '+08:00'",
            ]
        );
    }
    return $pdo;
}

if (PHP_SAPI !== 'cli') {
    session_set_cookie_params([
        'lifetime' => 0, 'path' => '/', 'httponly' => true,
        'samesite' => 'Strict', 'secure' => !empty($_SERVER['HTTPS']),
    ]);
    session_start();
}