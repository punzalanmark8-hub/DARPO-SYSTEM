-- DAR Ticketing & Appointment v2 (routing by office)  |  MySQL 8 / MariaDB 10.5+
-- Fresh install lang ito: i-drop muna ang lumang dar_ticketing database kung meron na.
CREATE DATABASE IF NOT EXISTS dar_ticketing CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE dar_ticketing;

-- Mga opisina / seksyon na humahawak ng ticket
CREATE TABLE units (
  id TINYINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(12) NOT NULL UNIQUE,
  name VARCHAR(80) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE services (
  id TINYINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  active TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

-- WORKFLOW TEMPLATE: sunud-sunod na opisina kada serbisyo
CREATE TABLE service_steps (
  service_id TINYINT UNSIGNED NOT NULL,
  step_no TINYINT UNSIGNED NOT NULL,
  unit_id TINYINT UNSIGNED NOT NULL,
  label VARCHAR(120) NOT NULL,
  PRIMARY KEY (service_id, step_no),
  FOREIGN KEY (service_id) REFERENCES services(id),
  FOREIGN KEY (unit_id) REFERENCES units(id)
) ENGINE=InnoDB;

CREATE TABLE staff (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(40) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  full_name VARCHAR(120) NOT NULL,
  unit_id TINYINT UNSIGNED NOT NULL,
  is_admin TINYINT(1) NOT NULL DEFAULT 0,
  FOREIGN KEY (unit_id) REFERENCES units(id)
) ENGINE=InnoDB;

CREATE TABLE queue_counters (
  queue_date DATE NOT NULL,
  ticket_type CHAR(1) NOT NULL,
  last_no INT UNSIGNED NOT NULL,
  PRIMARY KEY (queue_date, ticket_type)
) ENGINE=InnoDB;

-- status: 0 Nakarehistro, 1 Ongoing (nasa routing), 2 Tapos na
CREATE TABLE tickets (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  ref_no CHAR(15) NOT NULL UNIQUE,
  queue_date DATE NOT NULL,
  queue_no INT UNSIGNED NOT NULL,
  ticket_type CHAR(1) NOT NULL,
  full_name VARCHAR(120) NOT NULL,
  contact_no VARCHAR(30) NULL,
  service_id TINYINT UNSIGNED NOT NULL,
  appt_at DATETIME NULL,
  status TINYINT UNSIGNED NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_queue (queue_date, ticket_type, queue_no),
  KEY idx_board (queue_date, status),
  FOREIGN KEY (service_id) REFERENCES services(id)
) ENGINE=InnoDB;

-- Kopya ng workflow para sa bawat ticket (hindi apektado kung mabago ang template)
-- state: pending -> waiting (nasa pila ng opisina) -> processing (hawak ng staff) -> done
CREATE TABLE ticket_steps (
  ticket_id INT UNSIGNED NOT NULL,
  step_no TINYINT UNSIGNED NOT NULL,
  unit_id TINYINT UNSIGNED NOT NULL,
  label VARCHAR(120) NOT NULL,
  state ENUM('pending','waiting','processing','done') NOT NULL DEFAULT 'pending',
  ready_at DATETIME NULL,
  started_at DATETIME NULL,
  finished_at DATETIME NULL,
  staff_id INT UNSIGNED NULL,
  PRIMARY KEY (ticket_id, step_no),
  KEY idx_unit_state (unit_id, state),
  FOREIGN KEY (ticket_id) REFERENCES tickets(id),
  FOREIGN KEY (unit_id) REFERENCES units(id),
  FOREIGN KEY (staff_id) REFERENCES staff(id)
) ENGINE=InnoDB;

CREATE TABLE ticket_events (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  ticket_id INT UNSIGNED NOT NULL,
  step_no TINYINT UNSIGNED NULL,
  action VARCHAR(20) NOT NULL,          -- checkin | start | done | return
  staff_id INT UNSIGNED NULL,
  remarks VARCHAR(255) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_ticket (ticket_id),
  FOREIGN KEY (ticket_id) REFERENCES tickets(id)
) ENGINE=InnoDB;

-- ===== SAMPLE DATA (palitan ayon sa totoong proseso ng DAR office) =====
INSERT INTO units (id, code, name) VALUES
 (1,'FRONT','Front Desk (Receiving)'),
 (2,'RECORDS','Records Section'),
 (3,'LEGAL','Legal Division'),
 (4,'CASHIER','Cashier'),
 (5,'RELEASE','Releasing Section');

INSERT INTO services (id, name) VALUES
 (1,'Kopya ng Land Title (CLOA/EP)'),
 (2,'Certified True Copy ng Dokumento'),
 (3,'Land Ownership Inquiry'),
 (4,'Certification (DAR Clearance)'),
 (5,'Reklamo / Agrarian Case');

INSERT INTO service_steps (service_id, step_no, unit_id, label) VALUES
 (1,1,1,'Pagtanggap at pag-verify ng dokumento'),
 (1,2,2,'Paghahanap ng titulo sa records'),
 (1,3,3,'Pagsusuri at certification'),
 (1,4,4,'Pagbabayad ng fees'),
 (1,5,5,'Pagpapalabas ng kopya'),
 (2,1,1,'Pagtanggap at pag-verify ng dokumento'),
 (2,2,2,'Paghahanap at pagkopya ng dokumento'),
 (2,3,4,'Pagbabayad ng fees'),
 (2,4,5,'Pagpapalabas ng kopya'),
 (3,1,1,'Pagtanggap ng inquiry'),
 (3,2,2,'Pag-check sa records'),
 (3,3,5,'Pagbibigay ng sagot'),
 (4,1,1,'Pagtanggap at pag-verify ng dokumento'),
 (4,2,3,'Pagsusuri at pag-isyu ng certification'),
 (4,3,4,'Pagbabayad ng fees'),
 (4,4,5,'Pagpapalabas ng certification'),
 (5,1,1,'Pagtanggap ng reklamo'),
 (5,2,3,'Pagsusuri ng reklamo');

-- Gumawa ng staff gamit ang CLI:  php create_staff.php records1 "Juan Dela Cruz" RECORDS Pass1234
