DAR Ticketing at Appointment v2 (PHP + MySQL) - may routing kada opisina

Requirements: PHP 8.1+ (pdo_mysql), MySQL 8 / MariaDB 10.5+

SETUP
1. Fresh install: i-import ang schema.sql (i-drop muna ang lumang dar_ticketing DB kung meron).
2. Gumawa ng limited MySQL user at ilagay ang credentials sa config.php.
3. Gumawa ng staff kada opisina (CLI):
     php create_staff.php front1   "Maria Front"   FRONT   Pass12345
     php create_staff.php records1 "Juan Records"  RECORDS Pass12345
     php create_staff.php legal1   "Ana Legal"     LEGAL   Pass12345
     php create_staff.php cashier1 "Pedro Cashier" CASHIER Pass12345
     php create_staff.php release1 "Liza Release"  RELEASE Pass12345
     php create_staff.php admin    "DAR Admin"     FRONT   StrongPass1 --admin
4. I-upload ang index.html, api.php, config.php sa PHP server (hindi kailangan ang create_staff.php sa server
   kung sa ibang machine mo ito patatakbuhin; pero huwag itong ilagay sa public folder).
   Quick test: php -S localhost:8000

DAILOY (FLOW)
Client kumuha ng ticket -> QR/ref -> FRONT desk nag-scan = check-in (hakbang 1 -> "Naghihintay")
-> staff ng opisina: Simulan -> Tapos na (auto-route sa susunod na opisina) -> ... -> huling opisina = Tapos na ang ticket.
Ang opisina lang na may hawak ng kasalukuyang hakbang ang makakapag-update (admin lang ang may override).
Pwedeng "Ibalik sa nakaraang hakbang" na may remarks.

PAG-EDIT NG WORKFLOW
Ang units at service_steps tables sa schema.sql ang nagde-define ng ruta kada serbisyo. Baguhin ang INSERT
statements (o i-update ang table) para tumugma sa totoong proseso. Ang mga bagong ticket lang ang apektado.

NOTES
- Gamitin ang HTTPS sa production (kailangan para sa camera scan).
- Para sa offline LAN, i-host locally ang qrcode.min.js imbes na cdnjs.
